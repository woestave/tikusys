"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.consoleErrorCurried = void 0;
const consoleErrorCurried = function (...msg) {
    return function (x) {
        console.error('consoleErrorCurried::', ...msg);
        return x;
    };
};
exports.consoleErrorCurried = consoleErrorCurried;
