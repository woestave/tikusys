"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function serverJsonFieldReplace(str) {
    return str
        .replace(/\"/g, '\\\"')
        .replace(/\n/g, '\\n')
        .replace(/\r/g, '\\r');
}
exports.default = serverJsonFieldReplace;
