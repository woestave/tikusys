"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.jwtUnless = exports.JWT_SECRETS = exports.JWT_SECRET_TIKUSYS = exports.JWT_SECRET_EXAMSYS = exports.status401 = void 0;
const response_struct_1 = require("./response-struct");
function status401(context, next) {
    return next().catch(err => {
        if (err.status === 401) {
            context.body = (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.permissionDenied, response_struct_1.ERR_MESSAGES.permissionDenied, null);
        }
        else {
            throw err;
        }
    });
}
exports.status401 = status401;
exports.JWT_SECRET_EXAMSYS = 'examsys-secret-examsys';
exports.JWT_SECRET_TIKUSYS = 'examsys-secret-tikusys';
exports.JWT_SECRETS = [exports.JWT_SECRET_EXAMSYS, exports.JWT_SECRET_TIKUSYS];
exports.jwtUnless = [
    /\/examsys\/login/,
    /\/personnel\/teacher\/login/,
    /\/shell\/*/,
    // /\/examsys\/get-user-info/,
];
