"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/** 先解析路径 module-alias必须放到最上面 */
require("module-alias/register");
const module_alias_1 = __importDefault(require("module-alias"));
(0, module_alias_1.default)(__dirname + '/../package.json');
const chalk_1 = __importDefault(require("chalk"));
const koa_1 = __importDefault(require("koa"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const koa_logger_1 = __importDefault(require("koa-logger"));
// import cors from 'koa-cors';
const create_router_1 = require("./routes/create-router");
const jwts = __importStar(require("#/utils/jwt"));
const koa_jwt_1 = __importDefault(require("koa-jwt"));
const app = new koa_1.default();
app.use((0, koa_bodyparser_1.default)());
app.use(jwts.status401);
app.use((0, koa_jwt_1.default)({ secret: jwts.JWT_SECRETS, }).unless({ path: jwts.jwtUnless, }));
app.use((0, create_router_1.createRouter)());
app.use((0, koa_logger_1.default)());
app.on('error', (err, ctx) => console.error(`ERR::`, err, ctx));
exports.default = app;
const port = 4000;
app.listen(port);
console.log(chalk_1.default.green(`Server running on http://localhost:${port}`));
