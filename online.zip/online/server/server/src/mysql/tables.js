"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Tables = void 0;
const _1 = require(".");
exports.Tables = {
    Tiku: _1.SQL_CURD.of('tiku'),
    Exampaper: _1.SQL_CURD.of('exampaper'),
    Examination: _1.SQL_CURD.of('examination'),
    Class: _1.SQL_CURD.of('class'),
    ClassType: _1.SQL_CURD.of('class_type'),
    Relation__Exampaper__Tiku: _1.SQL_CURD.of('relation_exampaper_tiku'),
    Student: _1.SQL_CURD.of('student'),
    Teacher: _1.SQL_CURD.of('teacher'),
    ExamResult: _1.SQL_CURD.of('exam_result'),
    Major: _1.SQL_CURD.of('major'),
};
