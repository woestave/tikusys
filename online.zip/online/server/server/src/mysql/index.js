"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.beginTransaction = exports.createConnectionPromiseByPool = exports.SQL_CURD = exports.mysqlPool = void 0;
const mysql2_1 = __importDefault(require("mysql2"));
const SQL_1 = require("./SQL");
const mysql_CONFIG = {
    host: 'localhost',
    /** 线上线下数据库用户保持一致 */
    user: 'tiku_server',
    password: '123456',
    database: 'tiku_server',
};
// 创建一个数据库连接
exports.mysqlPool = mysql2_1.default.createPool(mysql_CONFIG);
// console.log('数据库连接信息：', JSON.stringify(mysql_CONFIG, null, 2));
exports.SQL_CURD = (0, SQL_1.getSQLTable)(exports.mysqlPool);
function createConnectionPromiseByPool() {
    return new Promise((resolve, reject) => {
        exports.mysqlPool.getConnection((err, connection) => {
            err ? reject(err) : resolve(connection);
        });
    });
}
exports.createConnectionPromiseByPool = createConnectionPromiseByPool;
function beginTransaction(fn) {
    return new Promise((resolve, reject) => {
        createConnectionPromiseByPool()
            .then((connection) => {
            const release = () => connection.release();
            const rollback = () => connection.rollback((err) => {
                if (err) {
                    console.error('事务回滚失败。');
                }
            });
            connection.beginTransaction((err) => {
                err
                    ? [reject(err), release()]
                    : fn(connection)
                        .then((res) => {
                        connection.commit((err) => {
                            if (err) {
                                reject(err);
                                rollback();
                            }
                            else {
                                resolve(res);
                            }
                        });
                    })
                        .catch((err) => {
                        reject(err);
                        rollback();
                    })
                        .finally(release);
            });
        })
            .catch(reject);
    });
}
exports.beginTransaction = beginTransaction;
