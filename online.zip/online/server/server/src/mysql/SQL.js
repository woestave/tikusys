"use strict";
/**
 * 本周第一天跟静静交接了题库系统的前端代码以及题库系统的墨刀原型图，熟悉了一遍代码，跑了一遍功能。
 *
 * 第二天构建了node后端代码，node环境部署完成，接口跑通了，
 *
 * 第三天(今天)数据库mysql构建完成，遇到一些问题也基本都解决了。
 * 与静静老师又过了一遍原型图，少量修改和删减了一些试卷的字段(所属阶段,是否AB卷,试卷数量)。
 *
 * todo: 学生在哪个系统考试 学生端\学生端和教师端是否分开\权限控制是否有需要 1\学生和老师的账号如何管理或注册 人工
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSQLTable = void 0;
const chalk_1 = __importDefault(require("chalk"));
const groupStartSymbol = Symbol('groupStart');
const groupEndSymbol = Symbol('groupEnd');
const orSymbol = Symbol('or');
const andSymbol = Symbol('and');
function getSQLTable(mysqlPool) {
    // const connectionPromisify = connection;
    class SQLTable {
        static of(tableName) {
            return new this({ tableName, });
        }
        get tableName() {
            return this.__value.tableName;
        }
        constructor(__value) {
            this.__value = __value;
        }
        of(__newValue) {
            return new this.constructor({
                ...this.__value,
                ...__newValue,
                tableName: __newValue.tableName || this.tableName,
            });
        }
        getFieldName(field) {
            return `\`${String(field)}\``;
        }
        getTableFieldName(field) {
            return `${this.tableName}.\`${String(field)}\``;
        }
        __validate(sqlType) {
            if (this.__value.sqlType && this.__value.sqlType !== sqlType) {
                throw Error(chalk_1.default.bgRed(`SQLTable::sql类型以固定为\`${this.__value.sqlType}\`操作，无法在此次sql语句内再次执行\`${sqlType}\`操作。`));
            }
        }
        insert(data) {
            return this.of({
                insertData: data,
                sqlType: 'C',
            });
        }
        delete() {
            return this.of({
                sqlType: 'D',
            });
        }
        update(newData) {
            return this.of({
                updateData: newData,
                sqlType: 'U',
            });
        }
        select(...fields) {
            return this.of({
                sqlType: 'R',
                selectFields: fields,
            });
        }
        pagination(pageNumber, pageSize) {
            return (typeof pageNumber === 'number' && typeof pageSize === 'number')
                ? this.limit((pageNumber - 1) * pageSize, pageSize)
                : this;
        }
        join(joinType, tableName, on) {
            return this.of({
                joinList: [
                    ...this.__value.joinList || [],
                    {
                        tableName: tableName instanceof SQLTable ? tableName.__value.tableName : tableName,
                        joinType,
                        on,
                    },
                ],
            });
        }
        limit(...limit) {
            return this.of({ limit, });
        }
        orderBy(orderBy) {
            return this.of({ orderBy, });
        }
        // public where (key: string, value: string | number): void;
        // public where (record: ): void;
        __checkWherePrevHasOp() {
            const whereList = (this.__value.whereList || []);
            const last = whereList[whereList.length - 1];
            return (typeof last === 'symbol' && [andSymbol, orSymbol, groupStartSymbol].includes(last)) || (whereList.length === 0);
        }
        where(key, op, value) {
            if ((value === void 0) || value === null || (Array.isArray(value) && value.length === 0)) {
                return this;
            }
            return this.of({
                whereList: [
                    ...this.__value.whereList || [],
                    ...this.__checkWherePrevHasOp() ? [] : [andSymbol],
                    { key, op, value: value, type: 'normal', },
                ],
            });
        }
        whereStr(whereStr) {
            return this.of({
                whereList: [
                    ...this.__value.whereList || [],
                    ...this.__checkWherePrevHasOp() ? [] : [andSymbol],
                    { key: '', op: '', value: whereStr, type: 'string', },
                ],
            });
        }
        or() {
            return this.of({
                whereList: [...this.__value.whereList || [], orSymbol],
            });
        }
        and() {
            return this.of({
                whereList: [...this.__value.whereList || [], andSymbol],
            });
        }
        groupStart() {
            return this.of({
                whereList: [
                    ...this.__value.whereList || [],
                    ...this.__checkWherePrevHasOp() ? [] : [andSymbol],
                    groupStartSymbol,
                ],
            });
        }
        groupEnd() {
            return this.of({
                whereList: [
                    ...this.__value.whereList || [],
                    groupEndSymbol,
                ],
            });
        }
        sql() {
            const sqls = [
                __getSqlBase(this.__value),
                __joinWhiteSpace(__getSqlWhere(this.__value.whereList || null)),
                __joinWhiteSpace(__getOrderBy(this.__value.orderBy || null)),
                __joinWhiteSpace(__getLimit(this.__value.limit || null)),
            ];
            return sqls.join('') + ';';
        }
        /**
         * 为了方便事务的封装 __exec接收一个连接池，一个事务中的操作都统一使用一个连接池
         */
        execBy(connection) {
            return new Promise((resolve, reject) => {
                connection.query(this.sql(), function (err2, result, fields) {
                    err2 ? reject(err2) : resolve(result);
                    connection.release();
                });
            });
        }
        /**
         * 事务的具名方法
         */
        execWithTransaction(connection) {
            return this.execBy(connection);
        }
        /**
         * 执行
         */
        exec() {
            return new Promise((resolve, reject) => {
                mysqlPool.getConnection((err1, connection) => {
                    if (err1) {
                        return reject(err1);
                    }
                    connection.beginTransaction;
                    resolve(this.execBy(connection));
                });
            });
            // const pro = mysqlPool.query(this.sql()).then((res) => res[0]) as Promise<
            //   ST extends 'R'
            //     ? Struct[]
            //     : ResultSetHeader
            // >;
            // return pro;
        }
    }
    return SQLTable;
}
exports.getSQLTable = getSQLTable;
// const ReservedWord = Object.freeze(['count(*)', 'count(1)']);
function joinSign(v) {
    // if (ReservedWord.includes(v)) {
    //   return v;
    // }
    return `\`${v}\``;
}
function __getSqlBase(__value) {
    var _a, _b, _c, _d;
    const tn = __value.tableName;
    switch (__value.sqlType) {
        case 'C':
            return `insert into ${tn} (${Object.keys(((_a = __value.insertData) === null || _a === void 0 ? void 0 : _a[0]) || {}).map(joinSign).join(', ')}) values ${(_b = __value.insertData) === null || _b === void 0 ? void 0 : _b.map((x) => {
                return `(${Object.values(x).map(__stringOrNumber).join(', ')})`;
            }).join(', ')}`;
        case 'U':
            return `update ${tn} set ${Object.keys(__value.updateData || {}).map((currKey) => {
                const updateData = __value.updateData;
                return `\`${currKey}\` = ${__stringOrNumber(updateData[currKey])}`;
            }).join(', ')}`;
        case 'R':
            const joinspace = (((_c = __value.joinList) === null || _c === void 0 ? void 0 : _c.length) ? ' ' : '');
            const joinstr = joinspace + (__value.joinList || []).map((x) => x.joinType + ' join ' + x.tableName + ' on ' + x.on).join(' ') + joinspace;
            return `select ${((_d = __value.selectFields) === null || _d === void 0 ? void 0 : _d.join(', ')) || '*'} from ${tn}${joinstr}`;
        case 'D':
            return `delete from ${tn}`;
        default: Error(chalk_1.default.bgRed(`__getPrefix::sql语句未指定CURD操作`));
    }
}
function __getSqlWhere(whereList) {
    const whereStrList = (whereList || []).map((curr) => {
        let res = '';
        if (curr === groupStartSymbol) {
            res = `(`;
        }
        else if (curr === groupEndSymbol) {
            res = `)`;
        }
        else if (curr === orSymbol) {
            res = `OR`;
        }
        else if (curr === andSymbol) {
            res = 'AND';
        }
        else if ('key' in curr && 'value' in curr) {
            switch (curr.type) {
                case 'normal':
                    res = `${curr.key} ${curr.op} ${Array.isArray(curr.value) ? `(${curr.value.map(__stringOrNumber).join(',')})` : __stringOrNumber(curr.value)}`;
                    break;
                case 'string':
                    res = curr.value;
                    break;
            }
        }
        return res;
    });
    return whereStrList.length ? 'where ' + whereStrList.join(' ') : '';
}
function __getOrderBy(orderBy) {
    const str = Object.keys(orderBy || {}).map((currKey) => {
        return currKey + ' ' + orderBy[currKey];
    });
    return str.length ? 'order by ' + str.join(', ') : '';
}
function __getLimit(limit) {
    return (limit === null || limit === void 0 ? void 0 : limit.length) > 0 ? 'limit ' + (limit === null || limit === void 0 ? void 0 : limit.join(', ')) || '' : '';
}
function __joinWhiteSpace(str) {
    return str ? ' ' + str : str;
}
function __stringOrNumber(v) {
    return typeof v === 'number'
        ? v
        : v === null
            ? 'NULL'
            : `"${(v || '')
            // .replace(/\'/g, `\\'`)
            }"`;
}
// function __getSqlLimit (sqlLimit?: SQLLimit) {
//   switch (sqlType) {
//     case 'C':
//     case 'U':
//     case 'D':
//       return '';
//     case 'R':
//       return fields?.join(',') || '';
//     default: Error(chalk.bgRed(`__getPrefix::sql语句未指定CURD操作`));
//   }
// }
