"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const querystring_1 = __importDefault(require("querystring"));
exports.default = (0, route_1.routePOST)((context, next) => {
    return tables_1.Tables
        .Tiku
        .where(tables_1.Tables.Tiku.getFieldName('id'), '=', context.request.body.tId)
        .select()
        .exec()
        .then(([tiItem]) => ({
        tiItem: tiItem ? {
            ...tiItem,
            tName: querystring_1.default.unescape(tiItem.tName || ''),
            customQuestionInfo: JSON.parse(querystring_1.default.unescape(tiItem.customQuestionInfo)),
        } : null,
    }));
});
