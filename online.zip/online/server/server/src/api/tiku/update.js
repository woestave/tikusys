"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tikuUpdate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const ramda_1 = require("ramda");
const querystring_1 = __importDefault(require("querystring"));
function tikuUpdate(body) {
    const question = body.question;
    const idKey = 'id';
    return tables_1.Tables
        .Tiku
        .update({
        ...(0, ramda_1.omit)([idKey], question),
        tName: querystring_1.default.escape(question.tName || ''),
        customQuestionInfo: querystring_1.default.escape(JSON.stringify(question.customQuestionInfo)),
    })
        .where(tables_1.Tables.Class.getFieldName('id'), '=', question.id)
        .exec()
        .then((res) => ({ succ: res.affectedRows, result: res, }));
}
exports.tikuUpdate = tikuUpdate;
exports.default = (0, route_1.routePOST)((context) => {
    return tikuUpdate(context.request.body);
});
