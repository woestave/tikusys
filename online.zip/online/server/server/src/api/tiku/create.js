"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tikuCreate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const querystring_1 = __importDefault(require("querystring"));
function tikuCreate(body) {
    const question = body === null || body === void 0 ? void 0 : body.question;
    const data = {
        ...question,
        tName: querystring_1.default.escape(question.tName || ''),
        customQuestionInfo: querystring_1.default.escape(JSON.stringify(body === null || body === void 0 ? void 0 : body.question.customQuestionInfo)),
        createBy: 1,
        createTime: +new Date(),
    };
    return tables_1.Tables
        .Tiku
        .insert([data])
        .exec()
        .then((res) => ({ succ: 1, res, }));
}
exports.tikuCreate = tikuCreate;
exports.default = (0, route_1.routePOST)((context) => {
    return tikuCreate(context.request.body);
});
