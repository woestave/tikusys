"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const ramda_1 = require("ramda");
const querystring_1 = __importDefault(require("querystring"));
exports.default = (0, route_1.routePOST)(async (context) => {
    const body = context.request.body;
    // const getSql = (limit?: [number, number]) => `\
    //   select\
    //     tiku.id as tikuId,\
    //     tName,\
    //     JSON_OBJECT('ids', JSON_ARRAYAGG(exampaper.id), 'names', JSON_ARRAYAGG(exampaper.paperName)) as paperInfo\
    //   from tiku left join exampaper on JSON_CONTAINS(paperQuestionInfo->'$.*', JSON_ARRAY(tiku.id))\
    //   where tiku.id like '%${(body.id || '').replace(/^0+/, '').trim()}%'\
    //   and (tName like '%${body.tName || ''}%' or customQuestionInfo like '%${body.tName || ''}%')\
    //   ${body.phase?.length ? 'and phase in (' + body.phase.join(',') + ')' : ''}\
    //   GROUP BY tiku.id\
    //   ${' '} ${limit ? limit[0] + ' ' + limit[1] : ''}\
    // `.replace('\\n', ' ');
    // const w = await connectionPromisify.query(getSql()).then((res) => {
    //   return res[0];
    // });
    const tName = querystring_1.default.escape(body.tName || '');
    const F = tables_1.Tables
        .Tiku
        .select()
        .where(tables_1.Tables.Tiku.getTableFieldName('id'), 'like', `%${(body.id || '').replace(/^0+/, '').trim()}%`)
        .groupStart()
        .where(tables_1.Tables.Tiku.getTableFieldName('tName'), 'like', `%${tName}%`)
        .or()
        .where(tables_1.Tables.Tiku.getTableFieldName('customQuestionInfo'), 'like', `%${tName}%`)
        .groupEnd()
        .where(tables_1.Tables.Tiku.getTableFieldName('phase'), 'in', body.phase)
        .where(tables_1.Tables.Tiku.getTableFieldName('major'), '=', body.major)
        .orderBy({ id: 'desc', });
    // return {
    //   list: [],
    //   total: 1,
    //   sql: F.sql(),
    // };
    return F
        .pagination(body.pageNumber, body.pageSize)
        .exec()
        .then((tikuList) => {
        return F.select('count(*) as total').exec().then(([total]) => {
            // Tables
            //   .Exampaper
            //   .select('id', 'paperName')
            //   .where('in', 'in', [])
            //   .exec().then((exampapers) => {
            //   });
            return tables_1.Tables
                .Relation__Exampaper__Tiku
                .join('left', tables_1.Tables.Exampaper, tables_1.Tables.Relation__Exampaper__Tiku.getTableFieldName('paperId') + '=' + tables_1.Tables.Exampaper.getTableFieldName('paperId'))
                .where(tables_1.Tables.Relation__Exampaper__Tiku.getTableFieldName('tikuId'), 'in', tikuList.map((0, ramda_1.prop)('id')))
                .select(tables_1.Tables.Exampaper.getTableFieldName('paperId'), tables_1.Tables.Exampaper.getTableFieldName('paperName'), tables_1.Tables.Relation__Exampaper__Tiku.getTableFieldName('tikuId'))
                .exec()
                .then((res) => {
                const list = tikuList.map((x) => ({
                    ...x,
                    tName: querystring_1.default.unescape(x.tName || ''),
                    paperInfo: res.filter((y) => y.tikuId === x.id),
                    customQuestionInfo: JSON.parse(querystring_1.default.unescape(x.customQuestionInfo)),
                }));
                return {
                    list,
                    total: (total === null || total === void 0 ? void 0 : total.total) || 0,
                };
            });
        });
    });
});
