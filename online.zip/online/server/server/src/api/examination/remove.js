"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    if (typeof body.id !== 'number' || body.id === 0) {
        return response_struct_1.responseStructPresets.reqBodyError;
    }
    return tables_1.Tables
        .Examination
        .delete()
        .where(tables_1.Tables.Examination.getFieldName('id'), '=', body.id)
        .exec()
        .then((res) => ({
        succ: res.affectedRows,
    }));
});
