"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.examinationCreate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
function examinationCreate(body, userInfo) {
    if (!body.examExampaperId
        || !body.examName
        || !body.examDate
        || !body.examDuration
        || (!Array.isArray(body.examClassIds) || body.examClassIds.length === 0)) {
        return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.reqBodyError, response_struct_1.ERR_MESSAGES.reqBodyError, null));
    }
    return tables_1.Tables
        .Examination
        .insert([{
            ...body,
            examClassIds: JSON.stringify(body.examClassIds),
            createTime: +new Date(),
            createBy: userInfo.teacherId,
        }])
        .exec()
        .then((res) => ({ succ: 1, res }));
}
exports.examinationCreate = examinationCreate;
exports.default = (0, route_1.routePOST)((cxt, next) => {
    const body = cxt.request.body;
    const userInfo = cxt.state.user;
    return examinationCreate(body, userInfo);
});
