"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const route_1 = require("#/routes/route");
const update_1 = require("./update");
const create_1 = require("./create");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    const userInfo = context.state.user;
    if (typeof body.id === 'number' && body.id !== 0) {
        return (0, update_1.examinationUpdate)(body).then((res) => ({
            ...res,
            type: 'update',
        }));
    }
    else {
        return (0, create_1.examinationCreate)(body, userInfo).then((res) => ({
            ...res,
            type: 'create',
        }));
    }
});
