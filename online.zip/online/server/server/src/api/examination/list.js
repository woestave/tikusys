"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
exports.default = (0, route_1.routePOST)(function (cxt, next) {
    const body = cxt.request.body;
    const F = tables_1.Tables
        .Examination
        .select()
        .orderBy({ createTime: 'desc', });
    return F.select('count(*) as total').exec().then(([{ total }]) => {
        return F
            .pagination(body.pageNumber, body.pageSize)
            .exec()
            // .then(objOf('list'));
            .then(list => ({
            list,
            total: total,
        }));
    });
});
