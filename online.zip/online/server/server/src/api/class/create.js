"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.classCreate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
function classCreate(body) {
    return tables_1.Tables.Class.insert([{
            ...body,
            createTime: +new Date(),
            classTeacher: JSON.stringify(body.classTeacher),
        }]).exec().then((res) => ({ succ: res.affectedRows, result: res, }));
}
exports.classCreate = classCreate;
exports.default = (0, route_1.routePOST)((context) => {
    return classCreate(context.body);
});
