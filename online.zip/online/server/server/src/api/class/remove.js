"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const response_struct_2 = require("#/utils/response-struct");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    if (typeof body.id !== 'number' || body.id === 0) {
        return response_struct_2.responseStructPresets.reqBodyError;
    }
    const condition = tables_1.Tables
        .Student
        .select(tables_1.Tables.Student.getFieldName('studentName'))
        .where(tables_1.Tables.Student.getFieldName('studentClass'), '=', body.id)
        .exec()
        .then((students) => {
        if (students.length) {
            return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.classHasStudentCannotDelete, response_struct_1.ERR_MESSAGES.classHasStudentCannotDelete, null));
        }
    });
    return condition.then(() => {
        return tables_1.Tables
            .Class
            .delete()
            .where(tables_1.Tables.Class.getFieldName('id'), '=', body.id)
            .exec()
            .then((res) => ({
            succ: res.affectedRows,
        }));
    });
});
