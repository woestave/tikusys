"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.classUpdate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const ramda_1 = require("ramda");
function classUpdate(body) {
    const idKey = 'id';
    return tables_1.Tables
        .Class
        .update({
        ...(0, ramda_1.omit)([idKey], body),
        classTeacher: JSON.stringify(body.classTeacher),
    })
        .where(tables_1.Tables.Class.getFieldName('id'), '=', body.id)
        .exec()
        .then((res) => ({ succ: res.affectedRows, result: res, }));
}
exports.classUpdate = classUpdate;
exports.default = (0, route_1.routePOST)((context) => {
    return classUpdate(context.request.body);
});
