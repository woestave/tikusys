"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    const F = tables_1.Tables.Class.select().orderBy({ createTime: 'desc' });
    return F
        .pagination(body.pageNumber, body.pageSize)
        .exec()
        .then((classList) => {
        return tables_1.Tables
            .Student
            .where(tables_1.Tables.Student.getFieldName('studentClass'), 'in', classList.map((x) => x.id))
            .select()
            .exec()
            .then((students) => {
            return F.select('count(*) as total').exec().then(([{ total }]) => ({
                list: classList.map((x) => ({
                    ...x,
                    studentCount: students.filter((student) => student.studentClass === x.id).length,
                })),
                total: total,
            }));
        });
    });
});
