"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const route_1 = require("#/routes/route");
const tables_1 = require("#/mysql/tables");
const teacher_role_1 = require("common-packages/constants/teacher-role");
const value_label_utils_1 = require("common-packages/utils/value-label-utils");
exports.default = (0, route_1.routePOST)((context, next) => {
    return Promise.all([
        tables_1.Tables.ClassType.select().exec(),
        tables_1.Tables.Class.select().exec(),
        tables_1.Tables.Major.select().exec(),
    ])
        .then(([classTypes, classes, majors]) => ({
        phases: [
            (0, value_label_utils_1.createValueLabelObj)(1, '阶段1'),
            (0, value_label_utils_1.createValueLabelObj)(2, '阶段2'),
            (0, value_label_utils_1.createValueLabelObj)(3, '阶段3'),
            (0, value_label_utils_1.createValueLabelObj)(4, '阶段4'),
            (0, value_label_utils_1.createValueLabelObj)(5, '阶段5'),
            (0, value_label_utils_1.createValueLabelObj)(6, '阶段6'),
        ],
        classes: classes.map((0, value_label_utils_1.getValueLabelCurried)('id', 'className')),
        classTypes: classTypes.map((0, value_label_utils_1.getValueLabelCurried)('id', 'classTypeName')),
        majors: majors.map((0, value_label_utils_1.getValueLabelCurried)('majorId', 'majorName')),
        studentStatus: [
            (0, value_label_utils_1.createValueLabelObj)(0, '正常'),
            (0, value_label_utils_1.createValueLabelObj)(1, '就业'),
            (0, value_label_utils_1.createValueLabelObj)(2, '休学'),
            (0, value_label_utils_1.createValueLabelObj)(3, '退学'),
        ],
        teacherStatus: [
            (0, value_label_utils_1.createValueLabelObj)(0, '正常'),
        ],
        teacherRoleMap: {
            [teacher_role_1.TeacherRole.super]: '超级管理员',
            [teacher_role_1.TeacherRole.teacher]: '讲师',
            [teacher_role_1.TeacherRole.eduAdmin]: '教务',
            [teacher_role_1.TeacherRole.visitor]: '游客',
        },
    }));
});
