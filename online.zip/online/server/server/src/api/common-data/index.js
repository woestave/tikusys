"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const route_1 = require("#/routes/route");
const tables_1 = require("#/mysql/tables");
const teacher_role_1 = require("common-packages/constants/teacher-role");
const value_label_utils_1 = require("common-packages/utils/value-label-utils");
exports.default = (0, route_1.routePOST)((context, next) => {
    return Promise.all([
        // Tables.ClassType.select().exec(),
        tables_1.Tables.Class.select().exec(),
        // Tables.Major.select().exec(),
    ])
        .then(([
    // classTypes,
    classes,
    // majors,
    ]) => ({
        phases: [
            (0, value_label_utils_1.createValueLabelObj)(1, '阶段1'),
            (0, value_label_utils_1.createValueLabelObj)(2, '阶段2'),
            (0, value_label_utils_1.createValueLabelObj)(3, '阶段3'),
            (0, value_label_utils_1.createValueLabelObj)(4, '阶段4'),
            (0, value_label_utils_1.createValueLabelObj)(5, '阶段5'),
            (0, value_label_utils_1.createValueLabelObj)(6, '阶段6'),
        ],
        classes: classes.map((0, value_label_utils_1.getValueLabelCurried)('id', 'className')),
        // classTypes: classTypes.map(getValueLabelCurried('id', 'classTypeName')),
        /**
         * 有class-type表，但暂时没用上
         */
        classTypes: [
            (0, value_label_utils_1.createValueLabelObj)(1, '威客学院（6个月）'),
            (0, value_label_utils_1.createValueLabelObj)(2, '蓝英学院（10个月）'),
            (0, value_label_utils_1.createValueLabelObj)(3, '立德学院（16个月）'),
            (0, value_label_utils_1.createValueLabelObj)(4, '齐齐哈尔分校'),
            (0, value_label_utils_1.createValueLabelObj)(5, '鸿蒙软件产业学院'),
        ],
        // majors表已存在，但没有做它的增删改查操作，这里选择不使用major表直接写死数据
        // majors: majors.map(getValueLabelCurried('majorId', 'majorName')),
        majors: [
            (0, value_label_utils_1.createValueLabelObj)(1, '大数据'),
            (0, value_label_utils_1.createValueLabelObj)(2, '大前端'),
            (0, value_label_utils_1.createValueLabelObj)(3, '云计算'),
            (0, value_label_utils_1.createValueLabelObj)(4, '影视制作'),
            (0, value_label_utils_1.createValueLabelObj)(5, '鸿蒙开发'),
            (0, value_label_utils_1.createValueLabelObj)(6, '软件测试'),
            (0, value_label_utils_1.createValueLabelObj)(7, '网络运维'),
            (0, value_label_utils_1.createValueLabelObj)(8, '专业基础'),
        ],
        studentStatus: [
            (0, value_label_utils_1.createValueLabelObj)(0, '正常'),
            (0, value_label_utils_1.createValueLabelObj)(1, '就业'),
            (0, value_label_utils_1.createValueLabelObj)(2, '休学'),
            (0, value_label_utils_1.createValueLabelObj)(3, '退学'),
        ],
        teacherStatus: [
            (0, value_label_utils_1.createValueLabelObj)(0, '正常'),
        ],
        teacherRoleMap: {
            [teacher_role_1.TeacherRole.super]: '超级管理员',
            [teacher_role_1.TeacherRole.teacher]: '讲师',
            [teacher_role_1.TeacherRole.eduAdmin]: '教务',
            [teacher_role_1.TeacherRole.visitor]: '游客',
        },
    }));
});
