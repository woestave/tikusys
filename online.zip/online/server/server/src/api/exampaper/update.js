"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.exampaperUpdate = void 0;
const mysql_1 = require("#/mysql");
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const ramda_1 = require("ramda");
function exampaperUpdate(body) {
    const idKey = 'paperId';
    if (!body.paperName || !body.paperTotalScore || (!Array.isArray(body.paperQuestionIds) || !body.paperQuestionIds.length)) {
        return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.reqBodyError, response_struct_1.ERR_MESSAGES.reqBodyError, null));
    }
    const tiIds = body.paperQuestionIds;
    /** 开启数据库事务 */
    return (0, mysql_1.beginTransaction)((connection) => {
        return tables_1.Tables
            .Exampaper
            .update({
            ...(0, ramda_1.omit)([idKey, 'paperQuestionIds'], body),
        })
            .where(tables_1.Tables.Exampaper.getFieldName('paperId'), '=', body.paperId)
            .execWithTransaction(connection)
            .then((res) => {
            return tables_1.Tables
                .Relation__Exampaper__Tiku
                .delete()
                .where(tables_1.Tables.Relation__Exampaper__Tiku.getFieldName('paperId'), '=', body[idKey])
                .execWithTransaction(connection);
        })
            .then(() => {
            return tables_1.Tables
                .Relation__Exampaper__Tiku
                .insert(tiIds.map((tikuId) => ({
                relationId: 0,
                tikuId,
                paperId: body[idKey],
            })))
                .execWithTransaction(connection);
        })
            .then(() => {
            return ({ succ: 1, });
        });
    });
}
exports.exampaperUpdate = exampaperUpdate;
exports.default = (0, route_1.routePOST)((context) => {
    return exampaperUpdate(context.request.body);
});
