"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const querystring_1 = __importDefault(require("querystring"));
exports.default = (0, route_1.routePOST)((context, next) => {
    return tables_1.Tables
        .Exampaper
        .where(tables_1.Tables.Exampaper.getFieldName('paperId'), '=', context.request.body.id)
        .select()
        .exec()
        .then(([editingPaperItem]) => {
        if (!editingPaperItem) {
            return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.reqBodyError, response_struct_1.ERR_MESSAGES.reqBodyError, null));
        }
        return tables_1.Tables
            .Relation__Exampaper__Tiku
            .join('left', tables_1.Tables.Tiku, `${tables_1.Tables.Relation__Exampaper__Tiku.getTableFieldName('tikuId')} = ${tables_1.Tables.Tiku.getTableFieldName('id')}`)
            .select()
            .where(tables_1.Tables.Relation__Exampaper__Tiku.getFieldName('paperId'), '=', editingPaperItem.paperId)
            .exec()
            .then((tiListOfThisPaper) => {
            return {
                paperItem: editingPaperItem ? {
                    ...editingPaperItem,
                } : null,
                tiListOfThisPaper: tiListOfThisPaper.map((x) => ({
                    ...x,
                    tName: querystring_1.default.unescape(x.tName || ''),
                    customQuestionInfo: JSON.parse(querystring_1.default.unescape(x.customQuestionInfo)),
                })),
            };
        });
    });
});
