"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const ramda_1 = require("ramda");
exports.default = (0, route_1.routePOST)(function (cxt, next) {
    return tables_1.Tables
        .Exampaper
        .select()
        .exec()
        .then((0, ramda_1.objOf)('list'));
});
