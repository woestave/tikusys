"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.exampaperCreate = void 0;
const mysql_1 = require("#/mysql");
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const ramda_1 = require("ramda");
function exampaperCreate(body) {
    if (!body.paperName || !body.paperTotalScore || (!Array.isArray(body.paperQuestionIds) || !body.paperQuestionIds.length)) {
        return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.reqBodyError, response_struct_1.ERR_MESSAGES.reqBodyError, null));
    }
    const tiIds = body.paperQuestionIds;
    /**
     * 开启事务
     */
    return (0, mysql_1.beginTransaction)((connection) => {
        return tables_1.Tables
            .Exampaper
            .insert([{
                ...(0, ramda_1.omit)(['paperQuestionIds'], body),
            }])
            .execWithTransaction(connection)
            .then((res) => {
            return tables_1.Tables
                .Relation__Exampaper__Tiku
                .insert(tiIds.map((tikuId) => ({
                relationId: 0,
                tikuId,
                paperId: res.insertId,
            })))
                .execWithTransaction(connection)
                .then((res) => ({ succ: 1, }));
        });
    });
}
exports.exampaperCreate = exampaperCreate;
exports.default = (0, route_1.routePOST)((req, next) => {
    const body = req.request.body;
    return exampaperCreate(body);
});
