"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
exports.default = (0, route_1.routePOST)(() => {
    return tables_1.Tables
        .ClassType
        .select()
        .exec()
        .then(list => ({
        list,
    }));
});
