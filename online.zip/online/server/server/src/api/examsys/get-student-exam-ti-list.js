"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const question_model_choice_1 = require("common-packages/models/question-model-choice");
const get_ti_list_by_paper_id_1 = require("./get-ti-list-by-paper-id");
const ramda_1 = require("ramda");
const exam_utils_1 = require("common-packages/helpers/exam-utils");
/**
 * 通过试卷id查询所有试卷所属的题列表，同时通过
 */
exports.default = (0, route_1.routePOST)((context) => {
    const userInfo = context.state.user;
    const body = context.request.body;
    if (typeof body.exampaperId !== 'number' || typeof body.examinationId !== 'number') {
        return response_struct_1.responseStructPresets.reqBodyError;
    }
    const examinationPromise = tables_1.Tables
        .Examination
        .select()
        .where(tables_1.Tables.Examination.getFieldName('id'), '=', body.examinationId)
        .exec();
    const myExamResultPromise = tables_1.Tables
        .ExamResult
        .select()
        .where(tables_1.Tables.ExamResult.getFieldName('examResultExaminationId'), '=', body.examinationId)
        .where(tables_1.Tables.ExamResult.getFieldName('examResultStudentId'), '=', userInfo.studentId)
        .exec();
    return Promise.all([
        examinationPromise,
        myExamResultPromise,
        (0, get_ti_list_by_paper_id_1.getTiListByPaperId)(body.exampaperId),
    ]).then(([[examination], [myExamResult], { tiList },]) => {
        return {
            tiList: tiList.map(x => ({
                ...x,
                /**
                 * 如果是选择题并且没有作答记录 则把正确答案right字段去掉 避免学生通过控制台network查看接口数据作弊
                 */
                ...((0, question_model_choice_1.filterIsChoiceQuestion)(x) && (!myExamResult && (0, exam_utils_1.inExamTime)(examination.examDate, examination.examDuration)) ? {
                    customQuestionInfo: {
                        ...x.customQuestionInfo,
                        /**
                         * 学生考试时，通过network查看tiList 可以看到选择题customQuestionInfo.choices[0].right是否正确来作弊
                         * 这里通过判断学生是否交卷（是否存在考试记录）来控制right字段是否要提供给前端。
                         * 如果学生没交卷，便不会提供给前端right字段，前端提交学生作答信息后从后端判卷。
                         */
                        choices: x.customQuestionInfo.choices.map((0, ramda_1.omit)(['right'])),
                        /**
                         * 去掉了right后，前端无法判断这是多选题还是单选题，这里提供题的类型
                         */
                        isSingle: (0, question_model_choice_1.filterSingleChoiceQuestion)(x),
                        isMulti: (0, question_model_choice_1.filterMultiChoiceQuestion)(x),
                    },
                } : {}),
            })),
        };
    });
});
