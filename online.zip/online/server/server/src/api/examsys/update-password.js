"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const md5_1 = require("#/utils/md5");
const response_struct_1 = require("#/utils/response-struct");
exports.default = (0, route_1.routePOST)((context) => {
    const userInfo = context.state.user;
    const body = context.request.body;
    return tables_1.Tables
        .Student
        .update({
        studentPwd: (0, md5_1.crypto_md5)(body.newPwd),
    })
        .where(tables_1.Tables.Student.getFieldName('studentId'), '=', userInfo.studentId)
        .where(tables_1.Tables.Student.getFieldName('studentPwd'), '=', (0, md5_1.crypto_md5)(body.oldPwd))
        .exec()
        .then((res) => {
        if (res.affectedRows === 1) {
            return {
                succ: 1,
            };
        }
        return (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.oldPwdWrong, response_struct_1.ERR_MESSAGES.oldPwdWrong, null);
    });
});
