"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// export default routePOST<API__Examsys__User.LoginReq, API__Examsys__User.LoginRes>((context) => {
// });
