"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
exports.default = (0, route_1.routePOST)((context) => {
    const userInfo = context.state.user;
    const body = context.request.body;
    const F = tables_1.Tables
        .Examination
        .select()
        .where(tables_1.Tables.Examination.getFieldName('id'), '=', body.id)
        .whereStr(`JSON_CONTAINS(examClassIds, JSON_ARRAY(${userInfo.studentClass || 0}))`);
    return F
        .exec()
        .then(([detail]) => {
        if (!detail) {
            return null;
        }
        return {
            ...detail,
        };
    });
});
