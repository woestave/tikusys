"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const route_1 = require("#/routes/route");
const jwt_1 = require("#/utils/jwt");
const response_struct_1 = require("#/utils/response-struct");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
exports.default = (0, route_1.routePOST)((context) => {
    const authorization = context.request.header.authorization;
    const token = authorization === null || authorization === void 0 ? void 0 : authorization.split(' ')[1];
    if (!token) {
        return (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.permissionDenied, response_struct_1.ERR_MESSAGES.permissionDenied, null);
    }
    const jwtResult = jsonwebtoken_1.default.verify(token, jwt_1.JWT_SECRET_TIKUSYS);
    return {
        token,
        userInfo: jwtResult,
    };
});
