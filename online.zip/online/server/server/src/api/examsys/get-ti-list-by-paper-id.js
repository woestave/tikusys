"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTiListByPaperId = void 0;
const tables_1 = require("#/mysql/tables");
const querystring_1 = __importDefault(require("querystring"));
function getTiListByPaperId(paperId) {
    const F = tables_1.Tables
        .Relation__Exampaper__Tiku
        .select()
        .join('left', tables_1.Tables.Tiku, `${tables_1.Tables.Tiku.getTableFieldName('id')} = ${tables_1.Tables.Relation__Exampaper__Tiku.getTableFieldName('tikuId')}`)
        .where(tables_1.Tables.Relation__Exampaper__Tiku.getFieldName('paperId'), '=', paperId);
    return F
        .exec()
        .then((tiList) => {
        return {
            tiList: tiList.map((x) => ({
                ...x,
                tName: querystring_1.default.unescape(x.tName || ''),
                customQuestionInfo: JSON.parse(querystring_1.default.unescape(x.customQuestionInfo)),
            })),
        };
    });
}
exports.getTiListByPaperId = getTiListByPaperId;
