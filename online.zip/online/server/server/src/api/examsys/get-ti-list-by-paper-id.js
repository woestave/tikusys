"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.selfFunction = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const querystring_1 = __importDefault(require("querystring"));
function selfFunction(paperId) {
    const F = tables_1.Tables
        .Relation__Exampaper__Tiku
        .select()
        .join('left', tables_1.Tables.Tiku, `${tables_1.Tables.Tiku.getTableFieldName('id')} = ${tables_1.Tables.Relation__Exampaper__Tiku.getTableFieldName('tikuId')}`)
        .where(tables_1.Tables.Relation__Exampaper__Tiku.getFieldName('paperId'), '=', paperId);
    return F
        .exec()
        .then((tiList) => {
        return {
            tiList: tiList.map((x) => ({
                ...x,
                tName: querystring_1.default.unescape(x.tName || ''),
                customQuestionInfo: JSON.parse(querystring_1.default.unescape(x.customQuestionInfo)),
            })),
        };
    });
}
exports.selfFunction = selfFunction;
/**
 * 通过试卷id查询所有试卷所属的题列表
 */
exports.default = (0, route_1.routePOST)((context) => {
    const userInfo = context.state.user;
    const body = context.request.body;
    if (typeof body.id !== 'number') {
        return response_struct_1.responseStructPresets.reqBodyError;
    }
    return selfFunction(body.id);
});
