"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const jwt_1 = require("#/utils/jwt");
const md5_1 = require("#/utils/md5");
const response_struct_1 = require("#/utils/response-struct");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    return tables_1.Tables
        .Student
        .select()
        .where(tables_1.Tables.Student.getFieldName('studentName'), '=', body.username)
        .where(tables_1.Tables.Student.getFieldName('studentPwd'), '=', (0, md5_1.crypto_md5)(body.password))
        .where(tables_1.Tables.Student.getFieldName('studentStatus'), '=', 0)
        .exec()
        .then((res) => {
        if (res.length === 1) {
            const temp = res[0];
            const userInfo = {
                studentId: temp.studentId,
                studentName: temp.studentName,
                studentStatus: temp.studentStatus,
                studentClass: temp.studentClass,
                studentCreateTime: temp.studentCreateTime,
            };
            const token = jsonwebtoken_1.default.sign(userInfo, jwt_1.JWT_SECRET_TIKUSYS, { expiresIn: '1d', });
            return {
                succ: 1,
                token,
            };
        }
        return (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.loginIncorrect, response_struct_1.ERR_MESSAGES.loginIncorrect, null);
    });
});
