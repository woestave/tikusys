"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
exports.default = (0, route_1.routePOST)((context) => {
    const userInfo = context.state.user;
    const examinationId = context.request.body.id;
    if (typeof examinationId !== 'number') {
        return response_struct_1.responseStructPresets.reqBodyError;
    }
    if (typeof (userInfo === null || userInfo === void 0 ? void 0 : userInfo.studentId) !== 'number') {
        return response_struct_1.responseStructPresets.permissionDenied;
    }
    // select * from examination where JSON_CONTAINS(examClassIds, JSON_ARRAY(18)) // 18是班级id 这条sql可以查询班级id为18的
    const F = tables_1.Tables
        .ExamResult
        .delete()
        .where(tables_1.Tables.ExamResult.getFieldName('examResultExaminationId'), '=', examinationId)
        .where(tables_1.Tables.ExamResult.getFieldName('examResultStudentId'), '=', userInfo.studentId);
    return F
        .exec()
        .then((res) => {
        return {
            succ: 1,
        };
    });
});
