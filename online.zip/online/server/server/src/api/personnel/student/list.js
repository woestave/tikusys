"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    const F = tables_1.Tables
        .Student
        .groupStart()
        .where(tables_1.Tables.Student.getFieldName('studentName'), 'like', `%${body.studentName || ''}%`)
        .or()
        .where(tables_1.Tables.Student.getFieldName('studentIdCard'), 'like', `%${body.studentName || ''}%`)
        .groupEnd()
        .where(tables_1.Tables.Student.getFieldName('studentClass'), '=', body.studentClass)
        .where(tables_1.Tables.Student.getFieldName('studentStatus'), '=', body.studentStatus)
        .orderBy({ studentId: 'desc', })
        .select();
    return F.select('count(*) as total').exec().then(([{ total }]) => {
        return F
            .pagination(body.pageNumber, body.pageSize)
            .exec()
            .then((list) => ({
            list,
            total: total,
        }));
    });
});
