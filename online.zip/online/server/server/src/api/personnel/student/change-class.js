"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    if (typeof body.studentId !== 'number' || typeof body.targetClassId !== 'number') {
        return (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.reqBodyError, response_struct_1.ERR_MESSAGES.reqBodyError, null);
    }
    return tables_1.Tables
        .Student
        .update({ studentClass: body.targetClassId, })
        .where(tables_1.Tables.Student.getTableFieldName('studentId'), '=', body.studentId)
        .exec()
        .then((res) => ({ succ: 1, }));
});
