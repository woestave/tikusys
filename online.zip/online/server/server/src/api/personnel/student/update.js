"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.studentUpdate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const ramda_1 = require("ramda");
function studentUpdate(body) {
    const idKey = 'studentId';
    return tables_1.Tables
        .Student
        .update({
        ...(0, ramda_1.omit)([idKey], body),
    })
        .where(tables_1.Tables.Student.getFieldName('studentId'), '=', body.studentId)
        .exec()
        .then((res) => ({ succ: res.affectedRows, result: res, }));
}
exports.studentUpdate = studentUpdate;
exports.default = (0, route_1.routePOST)((context) => {
    return studentUpdate(context.request.body);
});
