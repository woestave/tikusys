"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.studentCreate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const md5_1 = require("#/utils/md5");
function studentCreate(body) {
    function genDefaultTeacherPwd() {
        return (0, md5_1.crypto_md5)(body.studentIdCard);
    }
    return tables_1.Tables.Student.insert([
        {
            ...body,
            studentPwd: genDefaultTeacherPwd(),
            studentCreateTime: +new Date(),
        }
    ]).exec().then((res) => ({
        succ: 1,
    }));
}
exports.studentCreate = studentCreate;
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    return studentCreate(body);
});
