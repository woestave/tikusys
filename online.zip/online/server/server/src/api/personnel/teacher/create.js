"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.teacherCreate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const md5_1 = require("#/utils/md5");
function teacherCreate(body) {
    function genDefaultTeacherPwd() {
        return (0, md5_1.crypto_md5)(body.teacherIdCard);
    }
    return tables_1.Tables.Teacher.insert([
        {
            ...body,
            teacherPwd: genDefaultTeacherPwd(),
            teacherCreateTime: +new Date(),
        }
    ]).exec().then((res) => ({
        succ: 1,
    }));
}
exports.teacherCreate = teacherCreate;
exports.default = (0, route_1.routePOST)((context) => {
    return teacherCreate(context.request.body);
});
