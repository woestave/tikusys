"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const jwt_1 = require("#/utils/jwt");
const md5_1 = require("#/utils/md5");
const response_struct_1 = require("#/utils/response-struct");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    return tables_1.Tables
        .Teacher
        .select()
        .where(tables_1.Tables.Teacher.getFieldName('teacherName'), '=', body.username)
        .where(tables_1.Tables.Teacher.getFieldName('teacherPwd'), '=', (0, md5_1.crypto_md5)(body.password))
        .where(tables_1.Tables.Teacher.getFieldName('teacherStatus'), '=', 0)
        .exec()
        .then((res) => {
        if (res.length === 1) {
            const temp = res[0];
            const userInfo = {
                teacherId: temp.teacherId,
                teacherName: temp.teacherName,
                teacherStatus: temp.teacherStatus,
                teacherClass: temp.teacherClass,
                teacherCreateTime: temp.teacherCreateTime,
                taecherRole: temp.teacherRole,
            };
            const token = jsonwebtoken_1.default.sign(userInfo, jwt_1.JWT_SECRET_TIKUSYS, { expiresIn: '3d', });
            return {
                succ: 1,
                token,
            };
        }
        return (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.loginIncorrect, response_struct_1.ERR_MESSAGES.loginIncorrect, null);
    });
});
