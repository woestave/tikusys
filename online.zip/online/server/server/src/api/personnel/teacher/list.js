"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    // return Tables.Teacher.select().exec().then(list => {
    //   return {
    //     list,
    //     total: 0,
    //   };
    // });
    const F = tables_1.Tables
        .Teacher
        .groupStart()
        .where(tables_1.Tables.Teacher.getFieldName('teacherName'), 'like', `%${body.teacherName || ''}%`)
        .or()
        .where(tables_1.Tables.Teacher.getFieldName('teacherIdCard'), 'like', `%${body.teacherName || ''}%`)
        .groupEnd()
        .where(tables_1.Tables.Teacher.getFieldName('teacherClass'), '=', body.teacherClass)
        .where(tables_1.Tables.Teacher.getFieldName('teacherRole'), '=', body.teacherRole)
        .where(tables_1.Tables.Teacher.getFieldName('teacherStatus'), '=', body.teacherStatus)
        .orderBy({ teacherId: 'desc', })
        .select();
    return F.select('count(*) as total').exec().then(([{ total }]) => {
        return F
            .pagination(body.pageNumber, body.pageSize)
            .exec()
            .then((list) => ({
            list,
            total: total,
        }));
    });
});
