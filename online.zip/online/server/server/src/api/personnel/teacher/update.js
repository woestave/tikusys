"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.teacherUpdate = void 0;
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const ramda_1 = require("ramda");
function teacherUpdate(body) {
    const idKey = 'teacherId';
    return tables_1.Tables
        .Teacher
        .update({
        ...(0, ramda_1.omit)([idKey], body),
    })
        .where(tables_1.Tables.Teacher.getFieldName('teacherId'), '=', body.teacherId)
        .exec()
        .then((res) => ({ succ: res.affectedRows, result: res, }));
}
exports.teacherUpdate = teacherUpdate;
exports.default = (0, route_1.routePOST)((context) => {
    return teacherUpdate(context.request.body);
});
