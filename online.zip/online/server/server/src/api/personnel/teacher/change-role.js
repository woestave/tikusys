"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const teacher_role_1 = require("common-packages/constants/teacher-role");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    if (typeof body.teacherId !== 'number' || typeof body.targetRoleId !== 'number') {
        return (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.reqBodyError, response_struct_1.ERR_MESSAGES.reqBodyError, null);
    }
    return tables_1.Tables
        .Teacher
        .update({ teacherRole: body.targetRoleId, ...(body.targetRoleId === teacher_role_1.TeacherRole.teacher ? {} : { teacherClass: null, }) })
        .where(tables_1.Tables.Teacher.getFieldName('teacherId'), '=', body.teacherId)
        .exec()
        .then((res) => ({ succ: 1, }));
});
