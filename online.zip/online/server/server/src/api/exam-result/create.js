"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const compute_question_scores_1 = __importDefault(require("common-packages/helpers/compute-question-scores"));
const get_classify_questions_1 = __importDefault(require("common-packages/helpers/get-classify-questions"));
const node_querystring_1 = __importDefault(require("node:querystring"));
const get_ti_list_by_paper_id_1 = require("../examsys/get-ti-list-by-paper-id");
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    const answerInfo = body.answerInfo;
    const examinationId = body.examinationId;
    // const choiceQuestionScore = body.choiceQuestionScore;
    const userInfo = context.state.user;
    return (0, get_ti_list_by_paper_id_1.getTiListByPaperId)(body.exampaperId).then((res) => {
        const answerScores = (0, compute_question_scores_1.default)((0, get_classify_questions_1.default)(res.tiList || []), answerInfo);
        const choiceQuestionScore = answerScores.rightChoicesTotalScore;
        return tables_1.Tables
            .ExamResult
            .insert([
            {
                examResultId: 0,
                examResultAnswerInfo: node_querystring_1.default.escape(JSON.stringify(answerInfo)),
                examResultCreateTime: +new Date(),
                examResultExaminationId: examinationId,
                examResultStudentId: userInfo.studentId,
                examResultSQ_Marking: '',
                examResultChoiceQuestionScore: choiceQuestionScore,
            },
        ])
            .exec()
            .then((res) => {
            return { succ: 1, };
        });
    });
});
