"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const node_querystring_1 = __importDefault(require("node:querystring"));
exports.default = (0, route_1.routePOST)((context) => {
    const body = context.request.body;
    const answerInfo = body.answerInfo;
    const examinationId = body.id;
    const choiceQuestionScore = body.choiceQuestionScore;
    const userInfo = context.state.user;
    // for (let i in answerInfo) {
    //   const item = answerInfo[i];
    //   if (typeof item === 'string') {
    //     answerInfo[i] = (item);
    //   }
    // }
    // return getResponseStruct(333, 'ss', {
    //   sql: Tables
    //   .ExamResult
    //   .insert([
    //     {
    //       examResultId: 0,
    //       examResultAnswerInfo: querystring.stringify(answerInfo),
    //       examResultCreateTime: +new Date(),
    //       examResultExaminationId: examinationId,
    //       examResultStudentId: userInfo.studentId,
    //     },
    //   ]).sql(),
    // });
    return tables_1.Tables
        .ExamResult
        .insert([
        {
            examResultId: 0,
            examResultAnswerInfo: node_querystring_1.default.escape(JSON.stringify(answerInfo)),
            examResultCreateTime: +new Date(),
            examResultExaminationId: examinationId,
            examResultStudentId: userInfo.studentId,
            examResultSQ_Marking: '',
            examResultChoiceQuestionScore: choiceQuestionScore,
        },
    ])
        .exec()
        .then((res) => {
        return { succ: 1, };
    });
});
