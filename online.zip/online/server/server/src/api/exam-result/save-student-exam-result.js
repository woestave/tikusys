"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
exports.default = (0, route_1.routePOST)((context, next) => {
    // const userInfo = context.state.user as API__Teacher.GetUserInfoRes['userInfo'];
    const body = context.request.body;
    if (!body.examResultId) {
        return response_struct_1.responseStructPresets.reqBodyError;
    }
    return tables_1.Tables
        .ExamResult
        .update({
        examResultSQ_Marking: encodeURIComponent(JSON.stringify(body.SQMarking)),
    })
        .where(tables_1.Tables.ExamResult.getFieldName('examResultId'), '=', body.examResultId)
        .exec()
        .then((res) => {
        return { succ: res.affectedRows };
    });
});
