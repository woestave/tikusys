"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tables_1 = require("#/mysql/tables");
const route_1 = require("#/routes/route");
const response_struct_1 = require("#/utils/response-struct");
const get_ti_list_by_paper_id_1 = require("../examsys/get-ti-list-by-paper-id");
exports.default = (0, route_1.routePOST)((context, next) => {
    const userInfo = context.state.user;
    const body = context.request.body;
    const targetExamination = tables_1.Tables
        .Examination
        .select()
        .whereStr(`JSON_CONTAINS(${tables_1.Tables.Examination.getFieldName('examClassIds')}, JSON_ARRAY(${userInfo.teacherClass || 0}))`)
        .exec()
        .then((res) => {
        if (!res || res.length === 0) {
            return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.permissionDenied, '权限不足', null));
        }
        const targetExamination = res.find(x => +x.id === +body.examinationId);
        if (!targetExamination) {
            return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.notFound, '考试信息未找到。', null));
        }
        return targetExamination;
    });
    const targetExampaper = targetExamination.then(res => tables_1.Tables
        .Exampaper
        .select()
        .where(tables_1.Tables.Exampaper.getFieldName('paperId'), '=', res.examExampaperId)
        .exec()
        .then(([targetExampaper]) => {
        if (!targetExampaper) {
            return Promise.reject((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.exampaperNotExists, '试卷不存在！', null));
        }
        return targetExampaper;
    }));
    const targetExamResults = tables_1.Tables
        .ExamResult
        .select()
        .where(tables_1.Tables.ExamResult.getFieldName('examResultExaminationId'), '=', body.examinationId)
        .exec();
    // const tiList = Tables.Tiku.select().where(Tables.Tiku.getTableFieldName('id', 'in', ))
    const tiList = targetExampaper
        .then(res => (0, get_ti_list_by_paper_id_1.selfFunction)(res.paperId))
        .then((res) => {
        if (res instanceof response_struct_1.ResponseStruct) {
            return Promise.reject(res);
        }
        return res.tiList;
    });
    const studentList = targetExamResults.then((res) => tables_1.Tables
        .Student
        .select()
        .where(tables_1.Tables.Student.getFieldName('studentId'), 'in', res.map(x => x.examResultStudentId))
        .where(tables_1.Tables.Student.getFieldName('studentClass'), '=', userInfo.teacherClass) // 只要自己班的学生
        .exec());
    return Promise.all([
        targetExamination,
        tiList,
        targetExampaper,
        targetExamResults,
        studentList,
    ]).then(([examination, tiList, exampaper, examResults, studentList,]) => {
        const myStudentIds = studentList.map((x) => x.studentId);
        return {
            examination,
            exampaper,
            tiList,
            list: examResults.filter((x) => myStudentIds.includes(x.examResultStudentId)),
            studentList,
        };
    });
});
