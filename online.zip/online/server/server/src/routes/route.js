"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.routeALL = exports.routePOST = exports.routeGET = void 0;
const response_struct_1 = require("../utils/response-struct");
function routeFactory(method) {
    return function (fn) {
        const __ = (...args) => {
            return method === 'all'
                ? fn(...args)
                : args[0].request.method.toLowerCase() === method
                    ? fn(...args)
                    : (0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.notFound, response_struct_1.ERR_MESSAGES.apiNotFound, null);
        };
        return __;
    };
}
exports.routeGET = routeFactory('get');
exports.routePOST = routeFactory('post');
exports.routeALL = routeFactory('all');
