"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRouter = void 0;
const response_struct_1 = require("../utils/response-struct");
const chalk_1 = __importDefault(require("chalk"));
const path_1 = __importDefault(require("path"));
function getErrorStr(err) {
    var _a;
    if (err instanceof response_struct_1.ResponseStruct) {
        return err.errMsg;
    }
    return (((_a = err === null || err === void 0 ? void 0 : err.toString) === null || _a === void 0 ? void 0 : _a.call(err)) || (err === null || err === void 0 ? void 0 : err.message) || err) || (err === null || err === void 0 ? void 0 : err.toString());
    // return (err?.toString?.() || err?.message || err)?.split('Require stack:')?.[0] || err?.toString();
}
function createRouter(config = {
    rootPath: '/api',
}) {
    return function (ctx, next) {
        if (!ctx.path.startsWith(config.rootPath || '/api')) {
            return next();
        }
        // const sendBody = (function () {
        //   let sended = false;
        //   return function (body: any) {
        //     if (!sended) {
        //       ctx.body = body;
        //       sended = true;
        //     }
        //   };
        // })();
        function sendBody(body, status = 200) {
            ctx.status = status;
            ctx.body = body;
        }
        return Promise.resolve(`${path_1.default.resolve(__dirname, '../' + ctx.path)}`).then(s => __importStar(require(s))).then((res) => {
            if (!res.default || typeof res.default !== 'function') {
                sendBody((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.fatal, response_struct_1.ERR_MESSAGES.apiNotAFunction, null), 500);
            }
            else {
                return Promise
                    .resolve(new Promise((resolve, reject) => {
                    try {
                        resolve(res.default(ctx, next));
                    }
                    catch (e) {
                        reject(e);
                    }
                }))
                    .then((res) => {
                    // if (!res) {
                    //   return sendBody(getResponseStruct(ERR_CODES.canNotEmpty, ERR_MESSAGES.canNotEmpty, null));
                    // }
                    sendBody((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.noError, 'success', res || null));
                })
                    .catch((err) => {
                    const errStr = getErrorStr(err);
                    console.error(chalk_1.default.yellow('create-router::exec-err', errStr));
                    sendBody((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.fatal, errStr, null), /**500*/ 200);
                });
            }
        })
            .catch((err) => {
            const errStr = getErrorStr(err);
            console.error(chalk_1.default.red('create-router::import-err', errStr));
            sendBody((0, response_struct_1.getResponseStruct)(response_struct_1.ERR_CODES.fatal, errStr, null), 500);
        });
    };
}
exports.createRouter = createRouter;
