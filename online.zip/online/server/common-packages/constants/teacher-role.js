"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TeacherRole = void 0;
var TeacherRole;
(function (TeacherRole) {
    /**
     * 超管
     */
    TeacherRole[TeacherRole["super"] = 0] = "super";
    /**
     * 老师
     */
    TeacherRole[TeacherRole["teacher"] = 1] = "teacher";
    /**
     * 教务
     */
    TeacherRole[TeacherRole["eduAdmin"] = 2] = "eduAdmin";
    /**
     * 游客
     */
    TeacherRole[TeacherRole["visitor"] = 20] = "visitor";
})(TeacherRole || (exports.TeacherRole = TeacherRole = {}));
