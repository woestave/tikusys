"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MajorNames = exports.Majors = void 0;
var Majors;
(function (Majors) {
    Majors[Majors["FE"] = 1] = "FE";
    // JAVA = 2,
    Majors[Majors["BASE"] = 3] = "BASE";
    Majors[Majors["BIG_DATA"] = 4] = "BIG_DATA";
})(Majors || (exports.Majors = Majors = {}));
var MajorNames;
(function (MajorNames) {
    MajorNames["FE"] = "\u5927\u524D\u7AEF";
    MajorNames["BASE"] = "\u57FA\u7840\u8BFE";
    MajorNames["BIG_DATA"] = "\u5927\u6570\u636E";
})(MajorNames || (exports.MajorNames = MajorNames = {}));
