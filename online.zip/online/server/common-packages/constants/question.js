"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QuestionType = void 0;
var QuestionType;
(function (QuestionType) {
    /**
     * 未知
     */
    // unknown = 0,
    /**
     * 选择题
     */
    QuestionType[QuestionType["choiceQuestion"] = 1] = "choiceQuestion";
    /**
     * 简答题
     */
    QuestionType[QuestionType["shortAnswerQuestion"] = 2] = "shortAnswerQuestion";
})(QuestionType || (exports.QuestionType = QuestionType = {}));
