"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONST_COMMON = void 0;
exports.CONST_COMMON = {
    COM_NAME_EN: 'REACHEDTRAIN.COM',
    COM_NAME_CN: '锐时达',
    SYSTEM_NAME: '题库系统',
    EXAM_USER_COOKIE: 'EXAM_USER_BUSS',
};
