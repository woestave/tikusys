"use strict";
/* eslint-disable @typescript-eslint/no-unused-vars */
Object.defineProperty(exports, "__esModule", { value: true });
exports.sleepCurrying = exports.sleep = void 0;
/**
 * 😴😴😴😴😴😴😴😴睡觉函数
 * ```tsx
 * import sleep from '@/utils/sleep';
 *
 * async function exec () {
 *   console.log(1);
 *   await sleep(1000); // 等待1秒
 *   console.log(2); // 等待1秒后执行
 * }
 *
 * exec();
 * ```
 * jiangyantao@zuoyebang.com
 */
/* eslint space-before-function-paren: "error" */
/* eslint padded-blocks: 'off' */
/* eslint @typescript-eslint/no-non-null-assertion: 'off' */
function sleep(time = 0) {
    return new Promise((resolve, reject) => setTimeout(resolve, time));
}
exports.sleep = sleep;
/**
 * 柯里化sleep
 *
 * 不会污染返回值链
 * ```tsx
 * pipeWithPromise(
 *   () => 1
 *   sleepCurrying(1000),
 *   (n) => console.log('一秒后', n),
 *   sleepCurrying(1000),
 *   () => console.log('又一秒后'),
 * );
 * ```
 */
function sleepCurrying(time = 0) {
    return function Lambda(x) {
        // return sleep(time);
        return new Promise((resolve, reject) => {
            setTimeout(() => resolve(x), time);
        });
    };
}
exports.sleepCurrying = sleepCurrying;
