"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createValueLabelObj = exports.getValueLabelCurried = void 0;
function getValueLabelCurried(valueKey, labelKey) {
    return function (obj) {
        return {
            label: obj[labelKey],
            value: obj[valueKey],
        };
    };
}
exports.getValueLabelCurried = getValueLabelCurried;
function createValueLabelObj(value, label) {
    return {
        label, value,
    };
}
exports.createValueLabelObj = createValueLabelObj;
