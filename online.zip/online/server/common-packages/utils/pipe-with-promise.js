"use strict";
/**
 * 序列化函数并执行， @see pipe(), @see pipeP()
 *
 * 异步版的pipe
 *
 * 如果某个函数的返回值为Promise，则等待该Promise完成后取到Promise的值，再当做参数调用下一个函数
 *
 * @author jiangyantao@zuoyebang.com
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.pipeWithPromise = void 0;
const ramda_1 = require("ramda");
/**
 * ```tsx
 * pipeWithPromise(
 *   () => 1,
 *   (n) => 2,
 *   (n) => Promise.resolve('a,s,d'.repeat(n)), // -> "a,s,da,s,d"
 *   (s) => s.split(','), // -> ["a", "s", "da", "s", "d"]
 *   (arr) => arr.map(x => x.toUpperCase()), // -> ["A", "S", "DA", "S", "D"]
 *   sleepCurrying(1000), // 停止一秒
 *   tap<string[]>(console.log), // -> 打印 ["A", "S", "DA", "S", "D"]
 *   (arr) => arr.join(''), // -> "ASDASD"
 *   alert
 * )();
  // -> 一秒后， alert('ASDASD')
 * ```
 */
const pipeWithPromise = ((...fns) => {
    const fn = (0, ramda_1.pipeWith)((f, r) => r instanceof Promise ? r.then(f) : f(r))(fns);
    /**
     * 2021/11/28
     * 之所以包装一层return function而不直接返回fn是为了温和的处理rejected状态的promise
     * 某些被reject的Promise有目的且无害，如filterP、throttleP等工具函数都是通过reject来阻止函数继续向下流动。
     */
    return function (arg) {
        const res = Promise.resolve(fn(arg));
        return res.catch(e => e);
        // if (res instanceof Promise) {
        //   return res.catch(e => e);
        // }
        // return res;
    };
});
exports.pipeWithPromise = pipeWithPromise;
