"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.multiQuestionIsRight = exports.singleQuestionIsRight = void 0;
const ramda_1 = require("ramda");
/**
 * 判断单选题是否答对
 */
function singleQuestionIsRight(x, answer) {
    var _a;
    return (_a = x.customQuestionInfo.choices[answer[x.id]]) === null || _a === void 0 ? void 0 : _a.right;
}
exports.singleQuestionIsRight = singleQuestionIsRight;
/**
 * 判断多选题是否答对
 */
function multiQuestionIsRight(x, answer) {
    const myChoices = answer[x.id];
    if (!myChoices || myChoices.length === 0) {
        return false;
    }
    return x.customQuestionInfo.choices.every((y, yi) => y.right ? myChoices.indexOf(yi) >= 0 : myChoices.indexOf(yi) === -1);
}
exports.multiQuestionIsRight = multiQuestionIsRight;
const propScoreValue = (0, ramda_1.prop)('scoreValue');
function computeQuestionScores(classifyQuestions, answer) {
    const singles = classifyQuestions.singles.filter(x => singleQuestionIsRight(x, answer));
    const multiples = classifyQuestions.multiples.filter(x => multiQuestionIsRight(x, answer));
    const shorts = classifyQuestions.shorts;
    /** 做对的单选题总分 */
    const rightSingleScore = (0, ramda_1.sum)(singles.map(propScoreValue));
    /** 做对的多选题总分 */
    const rightMultiScore = (0, ramda_1.sum)(multiples.map(propScoreValue));
    /** 总分 */
    const totalScore = (0, ramda_1.sum)([...classifyQuestions.singles, ...classifyQuestions.multiples, ...classifyQuestions.shorts].map((x) => x.scoreValue) || []);
    /** 简答题总分 */
    const shortTotalScore = (0, ramda_1.sum)(shorts.map(propScoreValue));
    /** 选择题总分 */
    const choiceTotalScore = totalScore - shortTotalScore;
    /** 做对的选择题总分 */
    const rightChoicesTotalScore = rightSingleScore + rightMultiScore;
    return {
        singles, multiples, shorts,
        rightSingleScore,
        rightMultiScore,
        shortTotalScore,
        totalScore,
        choiceTotalScore,
        rightChoicesTotalScore,
    };
}
exports.default = computeQuestionScores;
