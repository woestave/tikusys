"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const question_model_choice_1 = require("common-packages/models/question-model-choice");
const question_model_short_1 = require("common-packages/models/question-model-short");
function getClassifyQuestions(questions) {
    const shorts = (questions.filter(question_model_short_1.filterIsShortQuestion) || []);
    const singles = (questions.filter(question_model_choice_1.filterSingleChoiceQuestion) || []);
    const multiples = (questions.filter(question_model_choice_1.filterMultiChoiceQuestion) || []);
    return {
        singles,
        multiples,
        shorts,
    };
}
exports.default = getClassifyQuestions;
