"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getQuestionTypeText = void 0;
const question_model_choice_1 = require("common-packages/models/question-model-choice");
const question_1 = require("common-packages/constants/question");
function getQuestionTypeText(question) {
    switch (question.customQuestionInfo.questionType) {
        case question_1.QuestionType.shortAnswerQuestion:
            return '简答题';
        case question_1.QuestionType.choiceQuestion:
            return (0, question_model_choice_1.filterSingleChoiceQuestion)(question)
                ? '单选题'
                : '多选题';
    }
}
exports.getQuestionTypeText = getQuestionTypeText;
