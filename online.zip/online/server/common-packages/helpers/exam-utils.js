"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.inExamTime = exports.getEndTime = void 0;
/**
 * 通过一个时间戳和一个分钟数获取这个时间戳加上分钟数后的时间戳
 */
function getEndTime(targetTime, duration) {
    return (targetTime + (duration * 60 * 1000));
}
exports.getEndTime = getEndTime;
/**
 * 判断当前时间是否在给定时间戳+给定持续时间之内
 */
function inExamTime(targetTime, duration) {
    return +new Date() > targetTime && +new Date() <= getEndTime(targetTime, duration);
}
exports.inExamTime = inExamTime;
