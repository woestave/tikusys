"use strict";
/**
 * 简答题 生成一个默认的简答题数据模型
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.filterIsShortQuestion = exports.getPartialShortQuestionModel = exports.getDefaultShortQuestionModel = void 0;
const question_1 = require("common-packages/constants/question");
const question_model_base_1 = require("./question-model-base");
function getDefaultShortQuestionModel() {
    return (0, question_model_base_1.getDefaultQuestionModel)(() => ({
        questionType: question_1.QuestionType.shortAnswerQuestion,
    }));
}
exports.getDefaultShortQuestionModel = getDefaultShortQuestionModel;
/**
 * 创建一个shortQuestionModel根据个别属性
 */
exports.getPartialShortQuestionModel = (0, question_model_base_1.getPartialQuestionModelFactory)(question_1.QuestionType.shortAnswerQuestion);
/**
 * 判断一个question是否属于简答题
 * @param anyQuestionModel 任何一个question类型的数据
 * @returns boolean
 */
function filterIsShortQuestion(anyQuestionModel) {
    return anyQuestionModel.customQuestionInfo.questionType === question_1.QuestionType.shortAnswerQuestion;
}
exports.filterIsShortQuestion = filterIsShortQuestion;
