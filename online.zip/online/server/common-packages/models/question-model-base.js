"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.questionTypeIs = exports.getPartialQuestionModelFactory = exports.getDefaultQuestionModel = void 0;
// export class QuestionModel1<CQI extends BaseCustomQuestionInfo> {
//   public id: number;
//   public tName: null | string;
//   public scoreValue: number;
//   public phase: null | number;
//   public customQuestionInfo: CQI;
//   public static partial<CQI extends BaseCustomQuestionInfo> (
//     questionType: QuestionType,
//     partialModel: Partial<Omit<QuestionModel<CQI>, 'customQuestionInfo'> & {
//       customQuestionInfo?: Omit<CQI, keyof BaseCustomQuestionInfo>;
//     }>
//   ) {
//     const _default = this.getDefaultQuestionModel<CQI>(() => ({
//       questionType,
//       ...partialModel.customQuestionInfo,
//     }));
//     return new this<CQI>({});
//   }
//   public static getDefaultQuestionModel<CQI extends BaseCustomQuestionInfo> (getCustomQuestionInfo: () => CQI) {
//     return new this<CQI>({
//       id: 0,
//       tName: null,
//       scoreValue: 1,
//       phase: null,
//       customQuestionInfo: getCustomQuestionInfo(),
//     });
//   }
//   public constructor (props: QuestionModel<CQI>) {
//     this.id = props.id;
//     this.tName = props.tName;
//     this.scoreValue = props.scoreValue;
//     this.phase = props.phase;
//     this.customQuestionInfo = props.customQuestionInfo;
//   }
// }
function getDefaultQuestionModel(getCustomQuestionInfo) {
    return {
        id: 0,
        tName: null,
        scoreValue: 1,
        phase: null,
        major: null,
        customQuestionInfo: getCustomQuestionInfo(),
    };
}
exports.getDefaultQuestionModel = getDefaultQuestionModel;
function getPartialQuestionModelFactory(questionType) {
    return function getPartialQuestionModel(partialModel) {
        const _default = getDefaultQuestionModel(() => ({ questionType, }));
        return {
            ..._default,
            ...partialModel,
            customQuestionInfo: {
                ..._default.customQuestionInfo,
                ...partialModel.customQuestionInfo,
            },
        };
    };
}
exports.getPartialQuestionModelFactory = getPartialQuestionModelFactory;
function questionTypeIs(question, questionType) {
    return question.customQuestionInfo.questionType === questionType;
}
exports.questionTypeIs = questionTypeIs;
