"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.filterIsChoiceQuestion = exports.filterMultiChoiceQuestion = exports.filterSingleChoiceQuestion = exports.getPartialChoiceQuestionModel = exports.getDefaultChoiceQuestionModel = exports.getDefaultChoises = exports.genChoiceModel = void 0;
const question_1 = require("common-packages/constants/question");
const question_model_base_1 = require("./question-model-base");
function genChoiceModel(label, right) {
    return {
        label,
        right: !!right,
    };
}
exports.genChoiceModel = genChoiceModel;
function getDefaultChoises() {
    return [
        genChoiceModel(''),
        genChoiceModel(''),
        genChoiceModel(''),
        genChoiceModel(''),
    ];
}
exports.getDefaultChoises = getDefaultChoises;
function getDefaultChoiceQuestionModel() {
    return (0, question_model_base_1.getDefaultQuestionModel)(() => ({
        questionType: question_1.QuestionType.choiceQuestion,
        choices: getDefaultChoises(),
        // choiceQuestionSubtype: ChoiceQuestionSubtype.unset,
    }));
}
exports.getDefaultChoiceQuestionModel = getDefaultChoiceQuestionModel;
/**
 * 创建一个choiceQuestionModel根据个别属性
 * ```tsx
 * const test = getPartialChoiceQuestionModel({
 *   tName: '测试1',
 *   customQuestionInfo: {
       choices: [genChoiceModel('选项1'), genChoiceModel('选项2', true)],
 *   },
 * });
 * console.log(test); -> {
 *   id: 0,
 *   tName: '测试1',
 *   scoreValue: 1,
 *   phase: null,
 *   customQuestionInfo: {
 *     questionType: QuestionType.choiceQuestion,
 *     choices: [{ label: '选项1', right: false, }, { label: '选项2', right: true, }],
 *   },
 * }
 * ```
 */
exports.getPartialChoiceQuestionModel = (0, question_model_base_1.getPartialQuestionModelFactory)(question_1.QuestionType.choiceQuestion);
/**
 * 判断该选择题是否属于单选题
 */
function filterSingleChoiceQuestion(questionModel) {
    return (0, question_model_base_1.questionTypeIs)(questionModel, question_1.QuestionType.choiceQuestion) && questionModel.customQuestionInfo.choices.filter(y => y.right).length === 1;
}
exports.filterSingleChoiceQuestion = filterSingleChoiceQuestion;
/**
 * 判断该选择题是否属于多选题
 */
function filterMultiChoiceQuestion(questionModel) {
    return (0, question_model_base_1.questionTypeIs)(questionModel, question_1.QuestionType.choiceQuestion) && questionModel.customQuestionInfo.choices.filter(y => y.right).length > 1;
}
exports.filterMultiChoiceQuestion = filterMultiChoiceQuestion;
/**
 * 判断一个question是否属于选择题
 * @param anyQuestionModel 任何一个question类型的数据
 * @returns boolean
 */
function filterIsChoiceQuestion(anyQuestionModel) {
    return anyQuestionModel.customQuestionInfo.questionType === question_1.QuestionType.choiceQuestion;
}
exports.filterIsChoiceQuestion = filterIsChoiceQuestion;
